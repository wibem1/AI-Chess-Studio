# Projektstand

Stand: 5. November 2026

## Verbindliches Ziel

Persönliches Schach-Lernprogramm: gegen eine Engine spielen und während/nach
der Partie mit einer getrennten KI über Stellung, Strategien und Varianten
lernen. Varianten ausprobieren, benennen, speichern und vergleichen, ohne die
Partie zu verändern. Siehe DEVELOPMENT_PLAN.md; bisherige Reduktion auf
Analysebrett/Faktencheck war ein Missverständnis und ist korrigiert.

## Neu implementiert und geprüft

- Stockfish 19 Lite WASM als realer automatischer Spielgegner. Farbe und fünf
  Skill-Stufen wählen; keine Elo-Zusage. Vollständige Zughistorie für Regeln
  und Wiederholung, keine Bewertungs-/Suchinfos aus Spielzügen im Dialog.
- Partiekursor getrennt vom Analysebrett: pausieren, frühere Stellung wählen,
  Varianten spielen, anschließend exakt zur tatsächlichen Partie zurückkehren.
  Der Einstieg in die Planfrage pausiert die Partie ebenfalls.
- Enginefehler pausieren ohne Auto-Retry. Späte Antworten nach Pause/Resume,
  anderer Partie oder Sitzungsersatz werden nicht angewendet.
- Varianten benennen und A/B vergleichen: zwei Stellungen, Zugfolgen,
  gemeinsamer Ausgangspunkt und jeweilige Notizen/Gespräche.
- Partie, Namen und Vergleich im validierten Schema-1-JSON erhalten. Alte
  Sitzungen weiterhin importierbar. UI-Import pausiert eine Partie, statt
  unaufgefordert die Engine starten zu lassen.
- KI-Kontext berücksichtigt Vorfahren der aktuellen Stellung, die Lernpartie
  und ausdrücklich gewählten Vergleich, bleibt auf sechs Einträge begrenzt.
- Typprüfung, Build, 68 Einzeltests und 23 Chromium-Browsertests bestanden.
  Echte lokale Engine auf allen fünf Stufen sowie Weiß-/Schwarz-Lernablauf im
  Browser geprüft; KI-Antworten weiterhin ausschließlich Testfixtures.
- Vorheriger Stand 6da1a54 bleibt erhalten. Details: docs/VALIDATION.md.

## Humanfaktor konkretisiert

Nutzerklarstellung: Die Lernanalyse soll menschliche Denkweise berücksichtigen,
nicht nur Enginewerte. DEVELOPMENT_PLAN.md und Modellauftrag ergänzt:
eigene Begründungen, Planverständnis, Kandidatenfindung, Rechenaufwand,
Genauigkeit, übersehbare Antworten, Weiterführung und persönlicher Lernwert.
Keine Einstufung des Menschen aus dem Engine-Level, keine erfundenen
Psychologie-/Enginewerte; praktische Umsetzbarkeit ist keine taktische Freigabe.
Implementiert ist die Instruktion; reale pädagogische Qualität noch nicht belegt.

## Neue Humanfaktor-Bedienung und Plattformbasis

- Stellungsbezogene Selbstangaben: Planidee, Begründung, Unsicherheit, Lernziel.
  Persistenz im Sitzungsformat und Übergabe als begrenzter Dialogkontext.
- Wahl zwischen Leitfrage, kleinem Hinweis und ausführlicher Erklärung. Leitfrage
  zeigt keine fertige Lösung; unerwünschte Zugkandidaten werden abgewiesen.
- Strukturierte menschliche Lernaspekte für moderne reale Antworten; fehlende/
  fehlerhafte Daten werden nicht still als vollständige Lernanalyse behandelt.
- Gemeinsame Web-/Touch-Basis, Manifest und Icons; Mac-.command-Starter.
  PLATFORM_ARCHITECTURE.md trennt Desktop-Backend von den noch erforderlichen
  mobilen Engine-/Transport-/Keystore-Adaptern. Keine mobile Standalone-Freigabe.

## Fortlaufender Lerndialog integriert

- Natürliche Dialogantwort vor aufklappbaren fachlichen Details; Gesprächsziele
  Stellung, Variantenvergleich und Partierückblick, vorbereiteter Einstieg.
- Rückfragen werden auf Klick in den Entwurf übernommen, nicht automatisch
  gesendet. Passende Beiträge früherer Stellungen bleiben sichtbar/verlinkt.
- Bis zu zwei echte frühere Gesprächsrunden mit separaten user/assistant-Rollen;
  keine simulierten Antworten als vermeintlich echte Modellvorgeschichte.
- Server validiert die tatsächliche Zugfolge gegen die angefragte FEN.
  Gekürzte Historie ist markiert; Unicode-Requestbudget unter 16 KiB geprüft.
- Voller Browserablauf mit echter Engine und tatsächlichem Modell-Service,
  Provider lokal ersetzt, drei Gesprächsrunden einschließlich Rückblick geprüft.
- Laufende Konfiguration und lokaler Schlüsselspeicher geprüft: kein nutzbarer
  realer Modellzugang in dieser Umgebung. Keine bezahlte Anfrage ausgeführt.

## Windows-Startfehler behoben

Nutzermeldung: tsc fehlt beim Build. Starter prüfte nur chess.js und übersah
fehlende Build-Werkzeuge. Windows-/Mac-Start und Selbstupdate installieren jetzt
explizit Entwicklungs-/optionale Pakete und Binärverknüpfungen. Fehler mit
npm ci --omit=dev nachgestellt; Reparatur selbst bei NODE_ENV=production
nachgewiesen. Anschließend Build, 64 Einzeltests und 19 Browsertests bestanden.
Keine Änderung an lokalen Schlüsseln oder Benutzerdaten.

## Figuren mit der Maus ziehen

- Direkte Brettbedienung mit Pointer Events: Figur folgt dem Zeiger, legale
  Zielfelder werden markiert. Loslassen spielt über dieselbe Regelprüfung wie
  Klick-/SAN-Eingabe; Stockfish antwortet im Spielmodus automatisch.
- Rochade, en passant, Schlagen und gewählte Unterumwandlung geprüft. Illegale
  Züge verändern die Stellung nicht; außerhalb loslassen, Escape, Fokusverlust
  und Pointerabbruch räumen die Ziehanzeige auf. Rendern bei Stellungswechsel
  verwirft einen noch laufenden Ziehvorgang.
- Vier neue Chromium-Maustests: legale/illegale Züge, Abbruch, Analysevarianten,
  Sonderzüge, echter Stockfish-Gegner sowie gedrehtes Brett als Schwarz.
  Typprüfung/Build, 64 Einzeltests und alle 23 Browsertests bestanden.
- Nutzer bestätigt inzwischen den erfolgreichen lokalen App-Start unter Windows.
  Mausbedienung ist unter Linux/Chromium geprüft; native Geräteabnahme bleibt offen.

## Lokaler Serverstart bei belegtem Port

Nutzermeldung: Installation und Build erfolgreich, danach generischer
Serverstartfehler. Der bisherige Fehlerhandler unterdrückte den OS-Fehlercode;
der genaue Fehler auf dem Nutzer-PC ist deshalb noch nicht belegt. Wahrscheinliche
Ursachen sind eine laufende vorherige App oder ein unter Windows reservierter Port.

- Default 5173 weicht bei EADDRINUSE/EACCES einmal auf einen vom Betriebssystem
  zugewiesenen freien Loopback-Port aus. Keine fremden Prozesse werden beendet.
- Browseröffnung und Konsolenausgabe verwenden die tatsächlich gebundene Adresse.
  Explizites CHESS_PORT bleibt fest; Startfehler nennen Ursache/OS-Code.
- Realer Sockettest und echter CLI-Start mit absichtlich belegtem 5173 erfolgreich;
  Ausweichadresse liefert App und API-Status. EACCES separat simuliert geprüft.
- Typprüfung/Build, 68 Einzeltests und 23 Browsertests bestanden. Nativer Test
  dieser Startkorrektur unter Windows noch offen.

## Weiter vorhandene Funktionen

Lokaler App-Server/Windows-Starter; private persistente Schlüsselablage
(Windows-DPAPI implementiert, unter Linux nicht nativ geprüft), Kostenbudget
als Schätzung, Diagnose, explizite Git-Updates und optionaler zusätzlicher
Stockfish-Faktencheck. Kein Schlüssel in Git, Diagnose oder Sitzungsexport.

## Grenzen und nächste Abnahme

Die echte KI ist noch nicht mit einem realen Schlüssel geprüft. Vorhandene
Freigabe für bis zu drei begrenzte reale Testversuche gilt; nicht erneut
erfragen und keinen Schlüssel im Chat anfordern. Lokaler PC-Eingabeweg ist
bevorzugt, weil Cloud-Bindungen hier nicht angewendet sichtbar waren.

Native Windows-/DPAPI-Prüfung und manueller Lerndurchlauf stehen aus. Sitzungen
werden bewusst als JSON gespeichert, keine automatische lokale Sitzungssicherung.
Skill-Stufen sind keine geeichten Elo-Werte. Budget ist keine verbindliche
Anbieterrechnung. Keine Veröffentlichung, Deployments, Releases, Actions oder
kostenpflichtige Textgenerierung durch den Agenten ausgeführt.

Nächster einzelner Schritt: realen Lern-Dialog zum eigenen Plan und zu einem
A/B-Vergleich prüfen, danach Ergebnisse und Projektstand gemeinsam sichern.
